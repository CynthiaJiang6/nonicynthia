var mode = 0;

function setup() {
  createCanvas(windowWidth, windowHeight);
  splash = new Splash();
}

function draw() {
  if (mouseIsPressed == true) {
    mode = 1;
  }
  if (mode == 1) {
    splash.hide();

 
  mode = 2;
  background(135, 206, 250); // Light blue sky background
  drawCloud(random(windowWidth/40,windowWidth), random(windowHeight/40,windowHeight/3), random(100,120), random(100,150));}



  
}

function drawCloud(x, y, width, height) {
  noStroke();
  let layers = random(10,40); // Number of layers to create the blur effect
  let alphaValue =random(80,200); // Starting alpha value for the topmost layer
  
  // Draw each layer with decreasing size and alpha
  for (let i = layers; i > 0; i--) {
    let ratio = i / layers;
    fill(255, alphaValue * ratio); // Adjust alpha value for blur effect
    ellipse(x, y, width * ratio * 0.5, height * ratio * 0.5);
    ellipse(x - random(40,60) * ratio, y, width * ratio*0.6, height * ratio*0.6);
    ellipse(x + random(30,40) * ratio, y, width * ratio*0.6, height * ratio*0.6);
    ellipse(x - random(10,30) * ratio, y - random(30,40) * ratio, width * ratio * 0.7, height * ratio * 0.7);
    ellipse(x + random(10,40) * ratio, y - random(30,40) * ratio, width * ratio * 0.7, height * ratio * 0.7);
  }
}

  



